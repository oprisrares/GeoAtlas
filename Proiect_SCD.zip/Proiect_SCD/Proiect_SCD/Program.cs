﻿using System;
using System.Windows.Forms;

namespace SpringApiClient
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
           
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1()); // Must match class name
        }
    }
}
